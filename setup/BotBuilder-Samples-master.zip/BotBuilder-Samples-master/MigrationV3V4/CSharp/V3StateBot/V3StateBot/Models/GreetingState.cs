﻿namespace V3StateBot.Models
{
    public class GreetingState
    {
        public string Name { get; set; }
        public string City { get; set; }
    }
}