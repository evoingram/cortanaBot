﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

namespace LivePersonProxyBot.Bots
{
    internal class UserProfile
    {
    }
}