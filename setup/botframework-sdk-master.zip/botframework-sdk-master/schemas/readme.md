# JsonSchema
This folder contains Json Schemas and samples for the bot framework SDK.

