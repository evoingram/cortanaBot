# packages

    * move/remove/ignore testbot

# core
# docs

# advanced topics
    * anatomy
    * upgrade guide

    * every adapter doc should link to main client API doc
    * link to provisioning guides

# github

    * tag new v4 branch

# starter kits / yeoman

    * move over more useful skills

# Teams 

    * direct_message qualifications
    * update/remove message in botworker?

    * -> https://github.com/howdyai/botkit/blob/master/lib/TeamsAPI.js
    * getchannels <-- can be achieved but is different/ and not compatible with getconversations
    * getuserbyid <-- predicated on getconvo members
    * getuserbyupn <-- see above
    * getconversationmembers <-- works but awkward
    * getteamroster <-- works but awkward
    * gettoken? <-- works but awkard>


# Tests!

# POST LAUNCH

    * update cms "options" page to reflect use with botkit-plugin-cms
    * botbuilder card builders?
    * ears? check for intent, others?
    * how to determine what is active dialog / do contextual help