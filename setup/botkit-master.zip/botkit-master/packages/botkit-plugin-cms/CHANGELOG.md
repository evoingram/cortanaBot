# botkit-plugin-cms

# botkit-plugin-cms changelog

# 1.0.3

* Emit a better error when an invalid token has been provided
* Update dependencies (Bot Framework to 4.6, Botkit to 4.6)


# 1.0.2

* Update dependencies (Bot Framework to 4.5.2, Botkit to 4.5)
* Improvements to reliability of the `uri` parameter on the constructor. 


# 1.0.1

* Fix critical issue that causes CMS-powered dialogs to fail to load.

# 1.0.0 

this was the initial release