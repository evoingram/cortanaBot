# Botkit Plugins

[&larr; Botkit Core Docs](../core.md)

* [Botkit CMS Plugin](../plugins/cms.md)
