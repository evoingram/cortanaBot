# botbuilder-adapter-twilio changelog

# 1.0.4

* Update dependencies (Bot Framework to 4.6, Botkit to 4.6)

# 1.0.2 

* Update dependencies (Bot Framework to 4.5.2, Botkit to 4.5)

# 1.0.1

* Add `enable_incomplete` option to allow adapter to start without a complete config.

# 1.0.0 

first public release