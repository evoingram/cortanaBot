# 4.6.3

Fix issue introduced in 4.6.2 that removed required .env file templates


# 4.6.1

* Update all environment variables to UPPER_CASE

# 4.5.1 

* Fix issue the typing indicator sample in the web starter kit

# 4.5.0

Update Botkit and Bot Framework package versions to latest
