// This is a generated file. Changes are likely to result in being overwritten
export const progressIndicator: string;
