// This is a generated file. Changes are likely to result in being overwritten
export const ngrokTab: string;
export const blinkerError: string;
export const tunnelError: string;
export const statusIndicator: string;
export const blinker: string;
export const tunnelInactive: string;
export const tunnelActive: string;
