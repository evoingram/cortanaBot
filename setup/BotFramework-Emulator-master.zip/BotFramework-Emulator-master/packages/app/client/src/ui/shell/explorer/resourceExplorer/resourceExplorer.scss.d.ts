// This is a generated file. Changes are likely to result in being overwritten
export const link: string;
export const explorerLink: string;
export const emptyContent: string;
