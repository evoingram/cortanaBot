// This is a generated file. Changes are likely to result in being overwritten
export const tab: string;
export const editorTabIcon: string;
export const livechat: string;
export const settings: string;
export const generic: string;
export const editorTabClose: string;
export const truncatedTabText: string;
export const draggedOverEditorTab: string;
export const activeEditorTab: string;
export const tabFocusTarget: string;
export const tabSeparator: string;
