// This is a generated file. Changes are likely to result in being overwritten
export const navBar: string;
export const navLink: string;
export const badge: string;
export const selected: string;
export const disabled: string;
