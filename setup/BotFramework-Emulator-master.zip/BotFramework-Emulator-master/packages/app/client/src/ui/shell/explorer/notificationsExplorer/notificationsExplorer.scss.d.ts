// This is a generated file. Changes are likely to result in being overwritten
export const notificationsExplorer: string;
export const clearAllNotificationsBtn: string;
export const noNotificationsMsg: string;
