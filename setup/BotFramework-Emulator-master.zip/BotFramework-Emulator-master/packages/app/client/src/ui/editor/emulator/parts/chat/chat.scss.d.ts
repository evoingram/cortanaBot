// This is a generated file. Changes are likely to result in being overwritten
export const bubbleContentColor: string;
export const bubbleBackground: string;
export const chat: string;
export const disconnected: string;
export const chatActivity: string;
export const hidden: string;
export const replayBubble: string;
export const selectedActivity: string;
export const botStateObject: string;
