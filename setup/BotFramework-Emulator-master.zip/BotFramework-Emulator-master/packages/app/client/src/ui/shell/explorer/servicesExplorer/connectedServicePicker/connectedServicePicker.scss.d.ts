// This is a generated file. Changes are likely to result in being overwritten
export const connectedServicePicker: string;
export const paddedLink: string;
export const checkboxOverride: string;
export const selectAll: string;
export const listContainer: string;
export const version: string;
export const containerName: string;
