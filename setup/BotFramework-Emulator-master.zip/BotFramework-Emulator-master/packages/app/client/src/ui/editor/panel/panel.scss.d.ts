// This is a generated file. Changes are likely to result in being overwritten
export const panel: string;
export const panelHeader: string;
export const accessories: string;
export const panelBody: string;
