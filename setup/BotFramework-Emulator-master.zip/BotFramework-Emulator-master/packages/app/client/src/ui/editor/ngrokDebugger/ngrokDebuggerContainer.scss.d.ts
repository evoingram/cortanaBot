// This is a generated file. Changes are likely to result in being overwritten
export const ngrokDebuggerContainer: string;
export const tunnelDetailsList: string;
export const errorDetailedViewer: string;
export const consoleViewer: string;
export const errorWindow: string;
export const spacing: string;
export const well: string;
