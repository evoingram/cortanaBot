// This is a generated file. Changes are likely to result in being overwritten
export const offline: string;
export const markdownContainer: string;
