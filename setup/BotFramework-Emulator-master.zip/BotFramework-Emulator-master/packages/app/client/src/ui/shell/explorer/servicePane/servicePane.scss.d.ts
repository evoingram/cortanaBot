// This is a generated file. Changes are likely to result in being overwritten
export const servicePane: string;
export const serviceIcon: string;
export const addIconButton: string;
export const sortIconButton: string;
export const emptyContent: string;
export const servicePaneList: string;
export const servicePaneExplorer: string;
export const containerExpanded: string;
