// This is a generated file. Changes are likely to result in being overwritten
export const link: string;
export const animateHighlight: string;
export const highlight: string;
export const cosmosDbIcon: string;
export const explorerLink: string;
export const emptyContent: string;
