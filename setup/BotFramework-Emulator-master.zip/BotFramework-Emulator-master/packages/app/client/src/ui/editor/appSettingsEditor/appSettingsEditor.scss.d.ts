// This is a generated file. Changes are likely to result in being overwritten
export const appSettingsEditor: string;
export const tunnelStatus: string;
export const marginBottomRow: string;
export const rightColumn: string;
export const buttonRow: string;
export const browseButton: string;
export const saveButton: string;
export const cancelButton: string;
export const sizeLimitSuffix: string;
export const checkboxOverrides: string;
export const inputContainer: string;
export const appSettingsInput: string;
export const spacing: string;
